-- Simulates and draws the 2 000 nanobot cubes: cloud around the leader, tornado at a clicked spot, giant wall on E.
-- Runs on each client every frame (RenderStepped), reading the swarm's orders from ReplicatedStorage.SwarmState.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SwarmConfig"))
local state = ReplicatedStorage:WaitForChild("SwarmState")

local player = Players.LocalPlayer

local N = Config.COUNT
local SIZE = Config.CUBE_SIZE
local HALF = SIZE / 2
local GAP = Config.MIN_GAP
local GAP2 = GAP * GAP
local INV_CELL = 1 / GAP

local sin, cos, sqrt, floor, min, random = math.sin, math.cos, math.sqrt, math.floor, math.min, math.random
local TAU = math.pi * 2

-- ── state of every bot, kept in plain number arrays for speed ─────────────────
local px, py, pz = table.create(N, 0), table.create(N, 0), table.create(N, 0)
local vx, vy, vz = table.create(N, 0), table.create(N, 0), table.create(N, 0)
local cxr, cyr, czr = table.create(N, 0), table.create(N, 0), table.create(N, 0) -- push-apart corrections
local ax, ay, az = table.create(N, 0), table.create(N, 0), table.create(N, 0) -- tumble angles
local sx, sy, sz = table.create(N, 0), table.create(N, 0), table.create(N, 0) -- tumble speeds

-- personal "seat" of every bot in the cloud and in the tornado
local phase, phase2, omega = table.create(N, 0), table.create(N, 0), table.create(N, 0)
local cloudR, cloudH = table.create(N, 0), table.create(N, 0)
local tornadoF, tornadoR = table.create(N, 0), table.create(N, 0)

-- wall slots (world space), waiting spots and release times
local slotX, slotY, slotZ = table.create(N, 0), table.create(N, 0), table.create(N, 0)
local stageX, stageY, stageZ = table.create(N, 0), table.create(N, 0), table.create(N, 0)
local release = table.create(N, 0)
local locked = table.create(N, false)

-- spatial hash (linked lists through `nextInCell`)
local head: { [number]: number } = {}
local nextInCell = table.create(N, 0)

local parts = table.create(N)
local cframes = table.create(N)

local rng = Random.new()

-- ── build the cubes (client-only parts) ───────────────────────────────────────
local folder = Instance.new("Folder")
folder.Name = "Nanobots"

for i = 1, N do
	local p = Instance.new("Part")
	p.Name = "Bot"
	p.Size = Vector3.new(SIZE, SIZE, SIZE)
	p.Anchored = true
	p.CanCollide = false
	p.CanQuery = false
	p.CanTouch = false
	p.Material = Enum.Material.Metal
	p.Color = Color3.fromRGB(18, 18, 21)
	p.Reflectance = 0.06
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth

	-- start as a flat heap on the floor ahead of the spawn (the camera starts behind the player)
	local a, r = rng:NextNumber(0, TAU), 14 * sqrt(rng:NextNumber())
	px[i], py[i], pz[i] = cos(a) * r, HALF, -22 + sin(a) * r
	p.CFrame = CFrame.new(px[i], py[i], pz[i])

	phase[i] = rng:NextNumber(0, TAU)
	phase2[i] = rng:NextNumber(0, TAU)
	local u = rng:NextNumber()
	cloudR[i] = Config.CLOUD_INNER + (Config.CLOUD_OUTER - Config.CLOUD_INNER) * sqrt(u)
	cloudH[i] = (rng:NextNumber() - 0.5) * Config.CLOUD_HEIGHT -- around chest height
	omega[i] = (1.6 / (0.35 * cloudR[i])) * rng:NextNumber(0.8, 1.2) -- inner bots swirl faster
	tornadoF[i] = sqrt((i - 0.5) / N)
	tornadoR[i] = rng:NextNumber(0.7, 1.3)
	sx[i], sy[i], sz[i] = rng:NextNumber(-2, 2), rng:NextNumber(-2, 2), rng:NextNumber(-2, 2)

	parts[i] = p
	cframes[i] = p.CFrame
	p.Parent = folder
	if i % 250 == 0 then
		task.wait() -- build in batches so the client stays responsive
	end
end
folder.Parent = workspace

-- ── orders from the server ────────────────────────────────────────────────────
local mode = "follow"
local modeTime = 0
local target = Vector3.zero
local wallCF = CFrame.new()
local wallRot = CFrame.new()
local scatterUntil = 0

local function assignWall()
	local cols, rows, sp = Config.WALL_COLS, Config.WALL_ROWS, Config.WALL_SPACING
	-- sort bots left→right as seen on the wall, then fill columns bottom→top:
	-- each bot goes to a slot close to where it already is, so paths do not cross
	local order = table.create(N, 0)
	local lx = table.create(N, 0)
	for i = 1, N do
		order[i] = i
		lx[i] = wallCF:PointToObjectSpace(Vector3.new(px[i], py[i], pz[i])).X
	end
	table.sort(order, function(a, b)
		return lx[a] < lx[b]
	end)
	local perCol = math.ceil(N / cols)
	local col = 0
	local k = 1
	while k <= N do
		local column = {}
		for j = k, min(N, k + perCol - 1) do
			table.insert(column, order[j])
		end
		table.sort(column, function(a, b)
			return py[a] < py[b]
		end)
		for row, i in column do
			local r = row - 1
			if r >= rows then
				r = rows - 1
			end
			local lxSlot = (col - (cols - 1) / 2) * sp
			local slot = wallCF:PointToWorldSpace(Vector3.new(lxSlot, HALF + r * sp, 0))
			slotX[i], slotY[i], slotZ[i] = slot.X, slot.Y, slot.Z
			-- wait in a low crowd in front of the wall until this row is called
			local stage = wallCF:PointToWorldSpace(
				Vector3.new(lxSlot + rng:NextNumber(-0.5, 0.5), 1 + rng:NextNumber(0, 6), -(3 + rng:NextNumber(0, 7)))
			)
			stageX[i], stageY[i], stageZ[i] = stage.X, stage.Y, stage.Z
			release[i] = modeTime + r * Config.WALL_ROW_DELAY + rng:NextNumber(0, 0.15)
			locked[i] = false
		end
		col += 1
		k += perCol
	end
end

local function assignTornado()
	-- bots that are higher now take the higher rings of the funnel
	local order = table.create(N, 0)
	for i = 1, N do
		order[i] = i
	end
	table.sort(order, function(a, b)
		return py[a] < py[b]
	end)
	for rank, i in order do
		tornadoF[i] = sqrt((rank - 0.5) / N)
	end
end

local function onOrder()
	local newMode = state:GetAttribute("Mode") :: string
	modeTime = state:GetAttribute("ModeTime") :: number
	target = state:GetAttribute("Target") :: Vector3
	local oldMode = mode
	mode = newMode

	if oldMode == "wall" and newMode ~= "wall" then
		-- the wall falls apart: every bot gets a kick and drops under gravity for a moment
		local push = wallCF.LookVector -- towards the player
		for i = 1, N do
			locked[i] = false
			local f = rng:NextNumber(0, 9)
			vx[i] = push.X * f + rng:NextNumber(-7, 7)
			vy[i] = rng:NextNumber(-2, 8)
			vz[i] = push.Z * f + rng:NextNumber(-7, 7)
			sx[i], sy[i], sz[i] = rng:NextNumber(-6, 6), rng:NextNumber(-6, 6), rng:NextNumber(-6, 6)
		end
		if newMode == "follow" then
			scatterUntil = modeTime + 1.6
		end
	end

	if newMode == "wall" then
		wallCF = state:GetAttribute("WallCFrame") :: CFrame
		wallRot = wallCF - wallCF.Position
		assignWall()
	elseif newMode == "tornado" then
		scatterUntil = 0
		assignTornado()
	end
end

onOrder()
state:GetAttributeChangedSignal("Seq"):Connect(onOrder)

-- ── who the cloud follows ─────────────────────────────────────────────────────
local function leaderRoot(): BasePart?
	local leader = Players:GetPlayerByUserId(state:GetAttribute("LeaderUserId") :: number) or player
	local character = leader.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not root and leader ~= player and player.Character then
		root = player.Character:FindFirstChild("HumanoidRootPart")
	end
	return root :: BasePart?
end

local centerX, centerY, centerZ = 0, 3, 0
local forwardX, forwardZ = 0, -1
local timeZero = floor(workspace:GetServerTimeNow())

-- ── one simulation step ───────────────────────────────────────────────────────
local function step(dt: number)
	dt = min(dt, 1 / 30)
	local now = workspace:GetServerTimeNow()
	local t = now - timeZero -- small number keeps sin/cos precise

	local camPos = workspace.CurrentCamera.CFrame.Position

	local root = leaderRoot()
	if root then
		local rp = root.Position
		-- "forward" = from my camera through the leader, so the cloud sits on the far side of them
		local fx, fz = rp.X - camPos.X, rp.Z - camPos.Z
		local fl = sqrt(fx * fx + fz * fz)
		if fl > 0.5 then
			local kf = min(1, dt * 4)
			forwardX += (fx / fl - forwardX) * kf
			forwardZ += (fz / fl - forwardZ) * kf
			local nl = sqrt(forwardX * forwardX + forwardZ * forwardZ)
			if nl > 1e-3 then
				forwardX, forwardZ = forwardX / nl, forwardZ / nl
			end
		end
		local k = min(1, dt * 5)
		centerX += (rp.X + forwardX * Config.CLOUD_FORWARD - centerX) * k
		centerY += (rp.Y + Config.CLOUD_CHEST - centerY) * k
		centerZ += (rp.Z + forwardZ * Config.CLOUD_FORWARD - centerZ) * k
	end

	-- my own character pushes bots away so they never sit inside it
	local myRoot = player.Character and player.Character:FindFirstChild("HumanoidRootPart") :: BasePart?
	local mx, my, mz = 1e9, 1e9, 1e9
	if myRoot then
		local p = myRoot.Position
		mx, my, mz = p.X, p.Y, p.Z
	end

	-- keep-clear tube from my camera to my character: no bot may block the view
	local hasView = myRoot ~= nil
	local ex, ey, ez, eLen2 = 0, 0, 0, 1
	if hasView then
		ex, ey, ez = mx - camPos.X, (my + Config.CLOUD_CHEST) - camPos.Y, mz - camPos.Z
		eLen2 = ex * ex + ey * ey + ez * ez
		hasView = eLen2 > 1
	end
	local camX, camY, camZ = camPos.X, camPos.Y, camPos.Z
	local CLEAR = Config.VIEW_CLEAR

	-- returns the point moved out of the tube (unchanged if it is already outside)
	local function clearView(x: number, y: number, z: number): (number, number, number)
		local s = ((x - camX) * ex + (y - camY) * ey + (z - camZ) * ez) / eLen2
		if s < 0 then
			return x, y, z
		end
		if s > 1 then
			s = 1
		end
		local qx, qy, qz = camX + ex * s, camY + ey * s, camZ + ez * s
		local dx, dy, dz = x - qx, y - qy, z - qz
		local d = sqrt(dx * dx + dy * dy + dz * dz)
		local r = CLEAR + (1 - s) * 1.5 -- a bit wider near the camera
		if d >= r then
			return x, y, z
		end
		if d < 1e-3 then
			-- right on the line: step sideways
			dx, dy, dz = -ez, 0, ex
			d = sqrt(dx * dx + dz * dz) + 1e-4
		end
		local m = r / d
		local nx, ny, nz = qx + dx * m, qy + dy * m, qz + dz * m
		if ny < HALF then
			ny = HALF
		end
		return nx, ny, nz
	end

	local scatter = now < scatterUntil
	local tX, tZ = target.X, target.Z
	local H = Config.TORNADO_HEIGHT
	local R0, R1 = Config.TORNADO_BASE_RADIUS, Config.TORNADO_TOP_RADIUS
	local wallMode = mode == "wall"

	for i = 1, N do
		local x, y, z = px[i], py[i], pz[i]
		local ux, uy, uz = vx[i], vy[i], vz[i]

		if scatter then
			-- falling apart: just gravity and air drag
			uy -= 90 * dt
			local drag = 1 - min(1, 0.6 * dt)
			ux *= drag
			uz *= drag
		elseif wallMode and locked[i] then
			ux, uy, uz = 0, 0, 0
		else
			local gx, gy, gz, maxSpeed, steer, gain
			if mode == "tornado" then
				local f = tornadoF[i]
				local r = (R0 + (R1 - R0) * f ^ 1.5) * tornadoR[i]
				local a = phase[i] + t * (4.2 - 2.4 * f)
				gx = tX + cos(a) * r + sin(t * 0.9 - f * 4) * f * 4
				gz = tZ + sin(a) * r + cos(t * 0.7 - f * 3) * f * 3
				gy = HALF + 0.2 + f * H
				maxSpeed, steer, gain = 110, 6, 4
			elseif wallMode then
				if now >= release[i] then
					gx, gy, gz = slotX[i], slotY[i], slotZ[i]
					maxSpeed, steer, gain = 70, 10, 6
				else
					gx, gy, gz = stageX[i], stageY[i], stageZ[i]
					maxSpeed, steer, gain = 90, 6, 4
				end
			else
				local a = phase[i] + t * omega[i]
				local r = cloudR[i] + sin(t * 0.7 + phase2[i]) * 1.2
				gx = centerX + cos(a) * r
				gz = centerZ + sin(a) * r
				gy = centerY + cloudH[i] + sin(t * 1.3 + phase2[i] * 2) * 1.1
				if gy < HALF + 0.2 then
					gy = HALF + 0.2
				end
				if hasView then
					-- seats that fall between the camera and the player slide aside
					gx, gy, gz = clearView(gx, gy, gz)
				end
				maxSpeed, steer, gain = 50, 3.5, 2.5
			end

			local dx, dy, dz = gx - x, gy - y, gz - z
			local d = sqrt(dx * dx + dy * dy + dz * dz)
			if wallMode and now >= release[i] and d < 0.12 then
				-- arrived: click into the wall
				locked[i] = true
				x, y, z = gx, gy, gz
				ux, uy, uz = 0, 0, 0
			else
				local speed = min(maxSpeed, d * gain)
				local s = d > 1e-4 and speed / d or 0
				local k = min(1, steer * dt)
				ux += (dx * s - ux) * k
				uy += (dy * s - uy) * k
				uz += (dz * s - uz) * k
			end
		end

		x += ux * dt
		y += uy * dt
		z += uz * dt

		-- keep out of my character's body
		local hx, hz = x - mx, z - mz
		local h2 = hx * hx + hz * hz
		if h2 < 6.25 and y < my + 3 and y > my - 3.5 and not locked[i] then
			local h = sqrt(h2) + 1e-4
			local push = (2.5 - h) / h
			x += hx * push
			z += hz * push
		end

		-- bots flying across the view are pushed out of the camera-to-player tube
		if hasView and not locked[i] then
			x, y, z = clearView(x, y, z)
		end

		if y < HALF then
			y = HALF
			if uy < 0 then
				uy = scatter and -uy * 0.3 or 0
			end
			if scatter then
				ux *= 0.85
				uz *= 0.85
			end
		end

		px[i], py[i], pz[i] = x, y, z
		vx[i], vy[i], vz[i] = ux, uy, uz
	end

	-- ── keep bots apart: spatial hash + pairwise push ─────────────────────────
	table.clear(head)
	for i = 1, N do
		local key = floor(px[i] * INV_CELL) + floor(py[i] * INV_CELL) * 4096 + floor(pz[i] * INV_CELL) * 16777216
		nextInCell[i] = head[key] or 0
		head[key] = i
		cxr[i], cyr[i], czr[i] = 0, 0, 0
	end

	for i = 1, N do
		local x, y, z = px[i], py[i], pz[i]
		local ix, iy, iz = floor(x * INV_CELL), floor(y * INV_CELL), floor(z * INV_CELL)
		local wi = locked[i] and 0 or 1
		for ox = -1, 1 do
			for oy = -1, 1 do
				for oz = -1, 1 do
					local j = head[(ix + ox) + (iy + oy) * 4096 + (iz + oz) * 16777216]
					while j and j ~= 0 do
						if j > i then
							local dx, dy, dz = px[j] - x, py[j] - y, pz[j] - z
							local d2 = dx * dx + dy * dy + dz * dz
							if d2 < GAP2 then
								local wj = locked[j] and 0 or 1
								local wsum = wi + wj
								if wsum > 0 then
									local d = sqrt(d2)
									if d < 1e-4 then
										-- exactly on top of each other: pick any direction
										dx, dy, dz = rng:NextNumber(-1, 1), rng:NextNumber(-1, 1), rng:NextNumber(-1, 1)
										d = sqrt(dx * dx + dy * dy + dz * dz) + 1e-4
									end
									local push = (GAP - d) / d / wsum
									local fi, fj = push * wi, push * wj
									cxr[i] -= dx * fi
									cyr[i] -= dy * fi
									czr[i] -= dz * fi
									cxr[j] += dx * fj
									cyr[j] += dy * fj
									czr[j] += dz * fj
								end
							end
						end
						j = nextInCell[j]
					end
				end
			end
		end
	end

	-- ── apply corrections, tumble and draw ────────────────────────────────────
	for i = 1, N do
		local x, y, z = px[i] + cxr[i] * 0.8, py[i] + cyr[i] * 0.8, pz[i] + czr[i] * 0.8
		if hasView and not locked[i] then
			x, y, z = clearView(x, y, z) -- push-apart must not shove a bot back into view
		end
		if y < HALF then
			y = HALF
		end
		px[i], py[i], pz[i] = x, y, z

		if locked[i] then
			cframes[i] = wallRot + Vector3.new(x, y, z)
		else
			local ux, uy, uz = vx[i], vy[i], vz[i]
			local spin = (0.35 + sqrt(ux * ux + uy * uy + uz * uz) * 0.06) * dt
			ax[i] += sx[i] * spin
			ay[i] += sy[i] * spin
			az[i] += sz[i] * spin
			cframes[i] = CFrame.new(x, y, z) * CFrame.fromEulerAnglesXYZ(ax[i], ay[i], az[i])
		end
	end

	workspace:BulkMoveTo(parts, cframes, Enum.BulkMoveMode.FireCFrameChanged)
end

RunService.RenderStepped:Connect(step)
