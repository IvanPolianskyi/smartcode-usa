-- Owns the swarm's orders: follow the leader, tornado at a clicked spot, or wall in front of the player.
-- Runs on the server; stores the order as attributes on ReplicatedStorage.SwarmState so every client draws the same swarm.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SwarmConfig"))

local state = Instance.new("Folder")
state.Name = "SwarmState"
state:SetAttribute("Mode", "follow")
state:SetAttribute("Target", Vector3.new(0, 0, 0))
state:SetAttribute("WallCFrame", CFrame.new())
state:SetAttribute("LeaderUserId", 0)
state:SetAttribute("ModeTime", workspace:GetServerTimeNow())
state:SetAttribute("Seq", 0)
state.Parent = ReplicatedStorage

local command = Instance.new("RemoteEvent")
command.Name = "SwarmCommand"
command.Parent = ReplicatedStorage

local function setMode(mode: string, leader: Player?)
	if leader then
		state:SetAttribute("LeaderUserId", leader.UserId)
	end
	state:SetAttribute("Mode", mode)
	state:SetAttribute("ModeTime", workspace:GetServerTimeNow())
	state:SetAttribute("Seq", (state:GetAttribute("Seq") :: number) + 1)
end

local function rootOf(player: Player): BasePart?
	local character = player.Character
	if not character then
		return nil
	end
	return character:FindFirstChild("HumanoidRootPart") :: BasePart?
end

local lastCommand: { [Player]: number } = {}

command.OnServerEvent:Connect(function(player: Player, action: any, point: any)
	local now = os.clock()
	if lastCommand[player] and now - lastCommand[player] < 0.25 then
		return
	end
	lastCommand[player] = now

	if action == "tornado" then
		if typeof(point) ~= "Vector3" or point.X ~= point.X or point.Z ~= point.Z then
			return
		end
		local limit = Config.FLOOR_LIMIT
		state:SetAttribute("Target", Vector3.new(math.clamp(point.X, -limit, limit), 0, math.clamp(point.Z, -limit, limit)))
		setMode("tornado", player)
	elseif action == "wall" then
		if state:GetAttribute("Mode") == "wall" then
			setMode("follow", player) -- second E: the wall falls apart
			return
		end
		local root = rootOf(player)
		if not root then
			return
		end
		local look = root.CFrame.LookVector * Vector3.new(1, 0, 1)
		if look.Magnitude < 0.01 then
			look = Vector3.new(0, 0, -1)
		end
		look = look.Unit
		local feet = Vector3.new(root.Position.X, 0, root.Position.Z)
		local base = feet + look * Config.WALL_DISTANCE
		state:SetAttribute("WallCFrame", CFrame.lookAt(base, feet)) -- the wall faces the player
		setMode("wall", player)
	elseif action == "recall" then
		setMode("follow", player)
	end
end)

-- the first player to join leads the swarm; if the leader leaves, someone else takes over
Players.PlayerAdded:Connect(function(player)
	if state:GetAttribute("LeaderUserId") == 0 then
		state:SetAttribute("LeaderUserId", player.UserId)
	end
end)

Players.PlayerRemoving:Connect(function(player)
	lastCommand[player] = nil
	if state:GetAttribute("LeaderUserId") == player.UserId then
		local others = Players:GetPlayers()
		local nextLeader = 0
		for _, other in others do
			if other ~= player then
				nextLeader = other.UserId
				break
			end
		end
		state:SetAttribute("LeaderUserId", nextLeader)
		setMode("follow", nil)
	end
end)

-- a tornado does not last forever: the swarm comes back to its leader
task.spawn(function()
	while true do
		task.wait(0.5)
		if state:GetAttribute("Mode") == "tornado" then
			local age = workspace:GetServerTimeNow() - (state:GetAttribute("ModeTime") :: number)
			if age > Config.TORNADO_LIFETIME then
				setMode("follow", nil)
			end
		end
	end
end)
