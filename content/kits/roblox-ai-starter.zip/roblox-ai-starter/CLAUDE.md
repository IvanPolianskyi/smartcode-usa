# Roblox games with Claude Code

You build Roblox games as Rojo projects. Every game lives in its own folder.

## How a game folder looks
```
my-game/
  default.project.json      Rojo project: maps src/ into the place
  src/server/*.server.luau  Scripts  -> ServerScriptService
  src/client/*.client.luau  LocalScripts -> StarterPlayer.StarterPlayerScripts
  src/shared/*.luau         ModuleScripts -> ReplicatedStorage.Shared
```
`default.project.json` must also set `Workspace` (with a Baseplate or a ground part),
`Lighting` (Technology = Future, nice ClockTime) and `StarterPlayer`.

## Build the place
When the code is ready, build a place file the user can double-click:
```
rojo build default.project.json -o game.rbxlx
```
Fix every build error before you say you are done.

Rojo property tips: to place a part from the project file use
`"CFrame": {"CFrame": {"position": [x, y, z], "orientation": [[1,0,0],[0,1,0],[0,0,1]]}}`
(`Position` is ignored there). Colors are `[r, g, b]` from 0 to 1.

## Rules for the code
- Luau, `--!strict` is not required. Use `task.wait`, `task.spawn`, `task.delay`, never `wait`/`spawn`.
- Build the world from code at server start (parts, terrain, lighting), so one `rojo build` gives a finished game.
- Many small parts: create them in batches, parent the folder last, and anchor everything that does not move.
  Keep the total under ~15 000 parts. Use `workspace:BulkMoveTo` for many parts moving each frame.
- Physics effects (breaking, flying blocks): unanchor only the parts that need to move, give them
  velocity with `AssemblyLinearVelocity`, and clean them up with `Debris` after a few seconds.
- Effects that only need to look good (waves, grass, swarms) run on the client in `RunService.RenderStepped`.
- Anything the player touches that changes the game runs on the server.
- Comment each script in two lines: what it does, where it runs.

## When you finish
Tell the user, in plain words: which file to open, what to press (Play), and what they will see.
