-- Builds the clean white lab around the floor: faint grid lines and tall white pillars far away.
-- Runs on the server once at start, so one rojo build gives a finished scene.

local floor = workspace:WaitForChild("Floor")

local world = Instance.new("Folder")
world.Name = "Lab"

local function makePart(size: Vector3, cf: CFrame, color: Color3, material: Enum.Material)
	local p = Instance.new("Part")
	p.Anchored = true
	p.CanTouch = false
	p.Size = size
	p.CFrame = cf
	p.Color = color
	p.Material = material
	p.TopSurface = Enum.SurfaceType.Smooth
	p.BottomSurface = Enum.SurfaceType.Smooth
	p.Parent = world
	return p
end

-- faint grid on the floor so the motion of the swarm is easy to read
local GRID_STEP = 16
local GRID_HALF = 256
local lineColor = Color3.fromRGB(222, 224, 230)
for i = -GRID_HALF, GRID_HALF, GRID_STEP do
	local a = makePart(Vector3.new(0.15, 0.02, GRID_HALF * 2), CFrame.new(i, 0.01, 0), lineColor, Enum.Material.SmoothPlastic)
	a.CanCollide = false
	a.CanQuery = false
	local b = makePart(Vector3.new(GRID_HALF * 2, 0.02, 0.15), CFrame.new(0, 0.01, i), lineColor, Enum.Material.SmoothPlastic)
	b.CanCollide = false
	b.CanQuery = false
end

-- a ring of tall white pillars on the horizon for scale
local PILLARS = 24
for i = 1, PILLARS do
	local angle = (i / PILLARS) * math.pi * 2
	local radius = 230 + (i % 3) * 25
	local height = 40 + (i * 37 % 60)
	local x, z = math.cos(angle) * radius, math.sin(angle) * radius
	makePart(
		Vector3.new(10, height, 10),
		CFrame.new(x, height / 2, z) * CFrame.Angles(0, angle, 0),
		Color3.fromRGB(246, 246, 248),
		Enum.Material.SmoothPlastic
	)
end

world.Parent = workspace
floor.Color = Color3.fromRGB(245, 245, 247)
