-- Shared settings for the block floor and the whirlpool funnel.
-- ModuleScript in ReplicatedStorage.Shared, used by both the server (builds floor) and the client (animates it).

local Config = {}

Config.GridSize = 120 -- blocks per side (120 x 120 = 14 400 blocks)
Config.BlockSize = 1 -- studs
Config.FloorTop = 0 -- Y of the floor surface at rest

Config.BaseColor = Color3.fromRGB(40, 105, 235)
Config.AltColor = Color3.fromRGB(34, 94, 220) -- checker tint so single blocks are readable
Config.DeepColor = Color3.fromRGB(6, 14, 52)
Config.RimColor = Color3.fromRGB(150, 225, 255)

-- Funnel shape
Config.Radius = 17 -- radius of the bowl
Config.Depth = 9 -- how deep the centre sinks
Config.RippleAmp = 0.9 -- height of rim ripples
Config.RippleWidth = 4.5 -- how wide the rippling band around the rim is
Config.SwirlAmp = 0.7 -- spiral arms inside the bowl
Config.SpinSpeed = 4.5 -- how fast ripples / arms spin

-- Spring that pulls each block to its target height
Config.Stiffness = 170
Config.Damping = 7 -- lower = more bounce when the floor springs back

return Config
