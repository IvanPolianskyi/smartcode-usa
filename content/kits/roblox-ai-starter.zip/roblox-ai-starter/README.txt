Roblox AI Game Kit - starter files

CLAUDE.md
  The rules file. Copy it into the folder where you keep your games.
  Claude Code reads it and builds every game as a Rojo project with a game.rbxlx at the end.

games/
  The three games from the kit, built by Claude Code from the prompts in the PDF.
  Double-click a .rbxlx file to open it in Roblox Studio, then press Play (F5).

Personal use only - please do not share or resell these files.
