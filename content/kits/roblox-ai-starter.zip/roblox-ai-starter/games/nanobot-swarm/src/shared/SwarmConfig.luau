-- Shared numbers for the nanobot swarm: cube count, wall size, tornado shape, speeds.
-- ModuleScript in ReplicatedStorage.Shared, read by the server and every client.

local SwarmConfig = {}

SwarmConfig.COUNT = 2000          -- number of nanobots
SwarmConfig.CUBE_SIZE = 0.75      -- edge of one cube (studs)
SwarmConfig.MIN_GAP = 0.9         -- two cube centres never get closer than this

-- Wall (E): COLS * ROWS must be >= COUNT
SwarmConfig.WALL_COLS = 50
SwarmConfig.WALL_ROWS = 40
SwarmConfig.WALL_SPACING = 1.0
SwarmConfig.WALL_DISTANCE = 18    -- how far in front of the player the wall stands
SwarmConfig.WALL_ROW_DELAY = 0.045 -- seconds between rows while the wall is building

-- Tornado (click)
SwarmConfig.TORNADO_HEIGHT = 70
SwarmConfig.TORNADO_BASE_RADIUS = 1.5
SwarmConfig.TORNADO_TOP_RADIUS = 17
SwarmConfig.TORNADO_LIFETIME = 15 -- seconds, then the swarm flies back to its leader

-- Cloud around the player: a swirling ring shifted forward (away from the camera), at chest height
SwarmConfig.CLOUD_INNER = 5.5     -- the player stands inside this hole
SwarmConfig.CLOUD_OUTER = 12
SwarmConfig.CLOUD_HEIGHT = 7      -- thickness of the band, centred on the chest
SwarmConfig.CLOUD_FORWARD = 4.5   -- ring centre is this far in front of the player
SwarmConfig.CLOUD_CHEST = 1.2     -- chest height above HumanoidRootPart
SwarmConfig.VIEW_CLEAR = 3.5      -- no bot inside this radius of the camera-to-player line

SwarmConfig.START_ZOOM = 25       -- camera distance when the game starts

SwarmConfig.FLOOR_LIMIT = 500     -- clicks outside this square are clamped

return SwarmConfig
