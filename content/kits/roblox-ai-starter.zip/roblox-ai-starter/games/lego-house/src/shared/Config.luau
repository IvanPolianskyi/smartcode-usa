-- Shared settings for the LEGO house: size, colors, hole shape and how blocks fly.
-- ModuleScript in ReplicatedStorage.Shared, used by the server scripts.

local Config = {}

-- House footprint in 1-stud cells (inclusive). Walls are one block thick.
Config.X0, Config.X1 = -12, 11 -- 24 blocks wide
Config.Z0, Config.Z1 = -9, 8 -- 18 blocks deep, front wall is Z1 (faces the spawn)
Config.WALL_HEIGHT = 11 -- block rows 0..10

-- Checker floor
Config.TILE = 8
Config.FLOOR_TILES = 32 -- 32 x 32 tiles = 256 x 256 studs

Config.SPAWN_POSITION = Vector3.new(0, 0.2, 36)

Config.Colors = {
	Wall = Color3.fromRGB(250, 238, 205),
	Frame = Color3.fromRGB(255, 255, 255),
	Glass = Color3.fromRGB(160, 215, 255),
	DoorA = Color3.fromRGB(124, 80, 46),
	DoorB = Color3.fromRGB(105, 66, 38),
	Knob = Color3.fromRGB(245, 200, 60),
	RoofA = Color3.fromRGB(200, 40, 35),
	RoofB = Color3.fromRGB(170, 30, 28),
	BrickA = Color3.fromRGB(150, 70, 55),
	BrickB = Color3.fromRGB(130, 58, 46),
	Cap = Color3.fromRGB(80, 80, 84),
	FloorLight = Color3.fromRGB(175, 177, 182),
	FloorDark = Color3.fromRGB(120, 122, 128),
}

-- Player-shaped hole, measured from the player's feet (ly) and centre line (lx).
-- A block breaks when its centre is inside one of these bands.
Config.HoleBands = {
	{ bottom = -0.3, top = 2.0, halfWidth = 1.2 }, -- legs
	{ bottom = 2.0, top = 4.0, halfWidth = 2.5 }, -- body and arms
	{ bottom = 4.0, top = 5.9, halfWidth = 1.4 }, -- head
}
Config.REACH = 1.5 -- studs ahead of the player that get broken
Config.LEAD_TIME = 0.15 -- extra reach per stud/second of speed (covers network delay)

-- Flying blocks
Config.FLY_SPEED_MIN, Config.FLY_SPEED_MAX = 20, 36
Config.FLY_UP_MIN, Config.FLY_UP_MAX = 6, 20
Config.SPIN = 14
Config.FALLEN_LIFETIME = 6

return Config
