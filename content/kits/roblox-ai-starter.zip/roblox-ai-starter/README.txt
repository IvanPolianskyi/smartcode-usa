ROBLOX AI GAME KIT - STARTER FILES
==================================

CLAUDE.md
  The rules file. Copy it into the folder where you keep all your games
  (for example Documents\roblox-games). Claude Code reads it automatically
  and builds every game as a Rojo project with a game.rbxlx at the end.

games\lego-house\      Game 1 - smash through a house made of 1-stud blocks
games\vortex-floor\    Game 2 - a floor of 14 400 blocks that sinks into a whirlpool
games\nanobot-swarm\   Game 3 - 2 000 cubes: click = tornado, E = wall, F = come back

Every game folder is the full project Claude Code wrote:
  default.project.json   the map of the game for Rojo
  src\server\            scripts that run on the server (world, rules)
  src\client\            scripts that run on each player's computer (smooth effects, UI)
  src\shared\            the settings file - change the numbers here
  game.rbxlx             the finished game

PLAY A GAME
  Double-click game.rbxlx. Roblox Studio opens it. Press F5 (Play).

CHANGE A GAME
  1. Copy the game folder into your games folder (next to CLAUDE.md).
  2. Right-click the game folder -> Open in Terminal -> type: claude
  3. Ask in plain words, for example: "Make the tornado twice as tall and rebuild game.rbxlx."
  4. Close the game in Studio and double-click game.rbxlx again.

REBUILD BY HAND
  In the game folder run:  rojo build default.project.json -o game.rbxlx

The guide (PDF) has the setup, the prompts, the numbers you can change and fix-it prompts.

Personal use only - please do not share or resell these files.
Results are not guaranteed. Not affiliated with Roblox or Anthropic.
