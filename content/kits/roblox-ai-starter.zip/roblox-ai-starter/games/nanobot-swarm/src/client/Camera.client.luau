-- Starts the camera zoomed out to about 25 studs so the player and the whole cloud are in view.
-- Runs on each client once, at the first spawn; after that the player can zoom freely.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("SwarmConfig"))
local player = Players.LocalPlayer

local character = player.Character or player.CharacterAdded:Wait()
character:WaitForChild("HumanoidRootPart")

-- the default camera keeps its zoom inside [Min, Max]: pin both to 25 for a moment, then free them
local normalMin, normalMax = player.CameraMinZoomDistance, player.CameraMaxZoomDistance
player.CameraMaxZoomDistance = math.max(normalMax, Config.START_ZOOM)
player.CameraMinZoomDistance = Config.START_ZOOM
-- give the camera's zoom spring time to settle at 25
RunService.RenderStepped:Wait()
task.wait(1)
player.CameraMinZoomDistance = normalMin
player.CameraMaxZoomDistance = math.max(normalMax, Config.START_ZOOM)
