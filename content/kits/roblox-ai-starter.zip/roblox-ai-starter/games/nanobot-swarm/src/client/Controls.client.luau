-- Player controls: click the floor for a tornado, E for the wall (again to break it), F to call the swarm back.
-- Runs on each client; sends orders to the server and shows a hint bar and a ring where you clicked.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local command = ReplicatedStorage:WaitForChild("SwarmCommand") :: RemoteEvent
local floor = workspace:WaitForChild("Floor")
local player = Players.LocalPlayer

-- ── hint bar ──────────────────────────────────────────────────────────────────
local gui = Instance.new("ScreenGui")
gui.Name = "SwarmHint"
gui.ResetOnSpawn = false

local label = Instance.new("TextLabel")
label.AnchorPoint = Vector2.new(0.5, 1)
label.Position = UDim2.new(0.5, 0, 1, -24)
label.Size = UDim2.fromOffset(560, 40)
label.BackgroundColor3 = Color3.fromRGB(15, 15, 18)
label.BackgroundTransparency = 0.25
label.TextColor3 = Color3.fromRGB(245, 245, 248)
label.Font = Enum.Font.GothamMedium
label.TextSize = 17
label.Text = "Click the floor: tornado   ·   E: build / break wall   ·   F: call swarm back"
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 10)
corner.Parent = label
label.Parent = gui
gui.Parent = player:WaitForChild("PlayerGui")

-- ── ring on the floor where you clicked ───────────────────────────────────────
local function showRing(point: Vector3)
	local ring = Instance.new("Part")
	ring.Shape = Enum.PartType.Cylinder
	ring.Anchored = true
	ring.CanCollide = false
	ring.CanQuery = false
	ring.CanTouch = false
	ring.Material = Enum.Material.Neon
	ring.Color = Color3.fromRGB(30, 30, 36)
	ring.Size = Vector3.new(0.05, 2, 2)
	ring.CFrame = CFrame.new(point + Vector3.new(0, 0.03, 0)) * CFrame.Angles(0, 0, math.rad(90))
	ring.Transparency = 0.2
	ring.Parent = workspace
	TweenService:Create(ring, TweenInfo.new(0.7, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
		Size = Vector3.new(0.05, 16, 16),
		Transparency = 1,
	}):Play()
	task.delay(0.8, function()
		ring:Destroy()
	end)
end

local rayParams = RaycastParams.new()
rayParams.FilterType = Enum.RaycastFilterType.Include
rayParams.FilterDescendantsInstances = { floor }

local function clickAt(ray: Ray)
	local hit = workspace:Raycast(ray.Origin, ray.Direction * 2000, rayParams)
	if hit then
		showRing(hit.Position)
		command:FireServer("tornado", hit.Position)
	end
end

UserInputService.InputBegan:Connect(function(input, processed)
	if processed then
		return
	end
	local camera = workspace.CurrentCamera
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		local m = UserInputService:GetMouseLocation()
		clickAt(camera:ViewportPointToRay(m.X, m.Y))
	elseif input.UserInputType == Enum.UserInputType.Touch then
		clickAt(camera:ScreenPointToRay(input.Position.X, input.Position.Y))
	elseif input.KeyCode == Enum.KeyCode.E then
		command:FireServer("wall")
	elseif input.KeyCode == Enum.KeyCode.F then
		command:FireServer("recall")
	end
end)
