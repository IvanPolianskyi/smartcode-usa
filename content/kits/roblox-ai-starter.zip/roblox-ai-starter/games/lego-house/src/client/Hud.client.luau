-- Shows a short hint ("Run into the house!") and a counter of knocked-off blocks.
-- Runs on each player's client (StarterPlayerScripts); reads the BlocksBroken attribute set by the server.

local Players = game:GetService("Players")
local TweenService = game:GetService("TweenService")

local player = Players.LocalPlayer

local gui = Instance.new("ScreenGui")
gui.Name = "LegoHud"
gui.ResetOnSpawn = false
gui.IgnoreGuiInset = true

local function label(text, size, posY)
	local l = Instance.new("TextLabel")
	l.AnchorPoint = Vector2.new(0.5, 0)
	l.Position = UDim2.new(0.5, 0, 0, posY)
	l.Size = UDim2.new(0, 520, 0, size + 10)
	l.BackgroundTransparency = 1
	l.Font = Enum.Font.FredokaOne
	l.TextSize = size
	l.TextColor3 = Color3.new(1, 1, 1)
	l.TextStrokeTransparency = 0.4
	l.Text = text
	l.Parent = gui
	return l
end

local hint = label("Run into the house!", 40, 70)
local counter = label("Blocks knocked off: 0", 24, 20)

gui.Parent = player:WaitForChild("PlayerGui")

local function update()
	counter.Text = ("Blocks knocked off: %d"):format(workspace:GetAttribute("BlocksBroken") or 0)
end
workspace:GetAttributeChangedSignal("BlocksBroken"):Connect(update)
update()

task.delay(6, function()
	local info = TweenInfo.new(1.5)
	TweenService:Create(hint, info, { TextTransparency = 1, TextStrokeTransparency = 1 }):Play()
end)
