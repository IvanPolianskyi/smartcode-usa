-- Builds the 120 x 120 floor of 1-stud blue blocks and invisible edge walls at server start.
-- Script in ServerScriptService; the client script then animates the blocks into a whirlpool.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("VortexConfig"))

local N = Config.GridSize
local S = Config.BlockSize
local half = N * S / 2
local y = Config.FloorTop - S / 2

local template = Instance.new("Part")
template.Anchored = true
template.Size = Vector3.new(S, S, S)
template.Material = Enum.Material.SmoothPlastic
template.Reflectance = 0.05
template.TopSurface = Enum.SurfaceType.Smooth
template.BottomSurface = Enum.SurfaceType.Smooth
template.CastShadow = false
template.CanTouch = false
template.CanQuery = false

local floor = Instance.new("Folder")
floor.Name = "VortexFloor"
floor:SetAttribute("BlockCount", N * N)

for i = 0, N - 1 do
	local x = -half + (i + 0.5) * S
	for j = 0, N - 1 do
		local z = -half + (j + 0.5) * S
		local block = template:Clone()
		block.Color = ((i + j) % 2 == 0) and Config.BaseColor or Config.AltColor
		block.CFrame = CFrame.new(x, y, z)
		block.Parent = floor
	end
	if i % 20 == 19 then
		task.wait() -- build in batches so the server does not freeze
	end
end

floor.Parent = workspace -- parent last: one replication burst

-- Invisible walls so nobody walks off the edge
local walls = Instance.new("Folder")
walls.Name = "EdgeWalls"
local wallHeight = 30
for _, info in ipairs({
	{ Vector3.new(half + 0.5, wallHeight / 2 - 12, 0), Vector3.new(1, wallHeight, N * S + 2) },
	{ Vector3.new(-half - 0.5, wallHeight / 2 - 12, 0), Vector3.new(1, wallHeight, N * S + 2) },
	{ Vector3.new(0, wallHeight / 2 - 12, half + 0.5), Vector3.new(N * S + 2, wallHeight, 1) },
	{ Vector3.new(0, wallHeight / 2 - 12, -half - 0.5), Vector3.new(N * S + 2, wallHeight, 1) },
}) do
	local wall = Instance.new("Part")
	wall.Anchored = true
	wall.Transparency = 1
	wall.CastShadow = false
	wall.Size = info[2]
	wall.Position = info[1]
	wall.Parent = walls
end
walls.Parent = workspace

-- If someone still falls into the abyss, bring them back
Players.PlayerAdded:Connect(function(player)
	player.CharacterAdded:Connect(function(character)
		local root = character:WaitForChild("HumanoidRootPart") :: BasePart
		task.spawn(function()
			while character.Parent do
				if root.Position.Y < -45 then
					root.CFrame = CFrame.new(0, 6, 0)
					root.AssemblyLinearVelocity = Vector3.zero
				end
				task.wait(0.5)
			end
		end)
	end)
end)
