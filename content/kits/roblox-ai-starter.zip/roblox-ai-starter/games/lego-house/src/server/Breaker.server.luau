-- Knocks a player-shaped hole in the house: blocks in front of a running player break off and fly away.
-- Runs on the server (ServerScriptService); flying blocks are removed after Config.FALLEN_LIFETIME seconds.

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local PhysicsService = game:GetService("PhysicsService")
local Debris = game:GetService("Debris")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))

local house = workspace:WaitForChild("House")

local flying = Instance.new("Folder")
flying.Name = "FlyingBlocks"
flying.Parent = workspace

workspace:SetAttribute("BlocksBroken", 0)

-- Flying blocks bounce off the ground, the house and each other, but never push the player.
PhysicsService:RegisterCollisionGroup("FlyingBlocks")
PhysicsService:RegisterCollisionGroup("Players")
PhysicsService:CollisionGroupSetCollidable("FlyingBlocks", "Players", false)

local function setGroup(inst)
	if inst:IsA("BasePart") then
		inst.CollisionGroup = "Players"
	end
end

local function onCharacter(character)
	for _, d in character:GetDescendants() do
		setGroup(d)
	end
	character.DescendantAdded:Connect(setGroup)
end

local function onPlayer(player)
	player.CharacterAdded:Connect(onCharacter)
	if player.Character then
		onCharacter(player.Character)
	end
end

Players.PlayerAdded:Connect(onPlayer)
for _, player in Players:GetPlayers() do
	onPlayer(player)
end

local overlap = OverlapParams.new()
overlap.FilterType = Enum.RaycastFilterType.Include
overlap.FilterDescendantsInstances = { house }

local rng = Random.new()
local bands = Config.HoleBands
local maxHalfWidth, holeTop = 0, 0
for _, b in bands do
	maxHalfWidth = math.max(maxHalfWidth, b.halfWidth)
	holeTop = math.max(holeTop, b.top)
end

local function inHole(lx, ly)
	for _, b in bands do
		if ly >= b.bottom and ly < b.top then
			return math.abs(lx) < b.halfWidth
		end
	end
	return false
end

local function launch(block, frame, lx)
	block.Parent = flying
	block.Anchored = false
	block.CollisionGroup = "FlyingBlocks"
	block:SetNetworkOwner(nil) -- server owns the physics, so the velocity below sticks

	local forward = frame.LookVector * rng:NextNumber(Config.FLY_SPEED_MIN, Config.FLY_SPEED_MAX)
	local up = Vector3.yAxis * rng:NextNumber(Config.FLY_UP_MIN, Config.FLY_UP_MAX)
	local side = frame.RightVector * (lx * rng:NextNumber(2, 5) + rng:NextNumber(-2, 2))
	block.AssemblyLinearVelocity = forward + up + side
	local s = Config.SPIN
	block.AssemblyAngularVelocity =
		Vector3.new(rng:NextNumber(-s, s), rng:NextNumber(-s, s), rng:NextNumber(-s, s))

	Debris:AddItem(block, Config.FALLEN_LIFETIME)
end

local function carve(root, humanoid, dir, speed)
	-- Feet height: R15 stands HipHeight above the floor under its root, R6 is 3 studs tall to the root centre.
	local feetY
	if humanoid.RigType == Enum.HumanoidRigType.R6 then
		feetY = root.Position.Y - 3
	else
		feetY = root.Position.Y - humanoid.HipHeight - root.Size.Y / 2
	end
	local base = Vector3.new(root.Position.X, feetY, root.Position.Z)
	local frame = CFrame.lookAt(base, base + dir)

	local reach = Config.REACH + speed * Config.LEAD_TIME
	local behind = 1
	local boxCFrame = frame * CFrame.new(0, holeTop / 2, -(reach - behind) / 2)
	local boxSize = Vector3.new(maxHalfWidth * 2 + 1, holeTop + 1, reach + behind + 1)

	local hits = workspace:GetPartBoundsInBox(boxCFrame, boxSize, overlap)
	local broken = 0
	for _, block in hits do
		local p = frame:PointToObjectSpace(block.Position)
		local ahead = -p.Z
		if ahead >= -behind and ahead <= reach and inHole(p.X, p.Y) then
			launch(block, frame, p.X)
			broken += 1
		end
	end
	if broken > 0 then
		workspace:SetAttribute("BlocksBroken", workspace:GetAttribute("BlocksBroken") + broken)
	end
end

RunService.Heartbeat:Connect(function()
	for _, player in Players:GetPlayers() do
		local character = player.Character
		local humanoid = character and character:FindFirstChildOfClass("Humanoid")
		local root = character and character:FindFirstChild("HumanoidRootPart")
		if humanoid and root and humanoid.Health > 0 then
			local v = root.AssemblyLinearVelocity
			local horizontal = Vector3.new(v.X, 0, v.Z)
			-- MoveDirection keeps working when the player is pressed against a wall and not moving yet.
			local dir = Vector3.new(humanoid.MoveDirection.X, 0, humanoid.MoveDirection.Z)
			if dir.Magnitude < 0.1 and horizontal.Magnitude > 4 then
				dir = horizontal
			end
			if dir.Magnitude >= 0.1 then
				carve(root, humanoid, dir.Unit, math.max(horizontal.Magnitude, humanoid.WalkSpeed))
			end
		end
	end
end)
