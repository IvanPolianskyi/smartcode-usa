-- Builds the world at start: grey checker floor, the 1-stud LEGO house, spawn pad and lighting effects.
-- Runs once on the server (ServerScriptService); house blocks go into workspace.House.

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Lighting = game:GetService("Lighting")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"))
local C = Config.Colors

---------------------------------------------------------------- checker floor
local floor = Instance.new("Folder")
floor.Name = "CheckerFloor"
do
	local t, n = Config.TILE, Config.FLOOR_TILES
	for i = 0, n - 1 do
		for j = 0, n - 1 do
			local tile = Instance.new("Part")
			tile.Anchored = true
			tile.Locked = true
			tile.Size = Vector3.new(t, 0.2, t)
			tile.CFrame = CFrame.new((i - n / 2 + 0.5) * t, -0.1, (j - n / 2 + 0.5) * t)
			tile.Color = (i + j) % 2 == 0 and C.FloorLight or C.FloorDark
			tile.Material = Enum.Material.SmoothPlastic
			tile.TopSurface = Enum.SurfaceType.Smooth
			tile.BottomSurface = Enum.SurfaceType.Smooth
			tile.Parent = floor
		end
	end
end
floor.Parent = workspace

---------------------------------------------------------------- house layout
-- Each cell is one 1x1x1 block at grid (x, y, z). First write wins.
local cells = {}
local order = {}

local function put(x, y, z, color, kind)
	local key = x .. "," .. y .. "," .. z
	if cells[key] then
		return
	end
	cells[key] = { x = x, y = y, z = z, color = color, kind = kind or "solid" }
	table.insert(order, key)
end

-- Openings per wall, in wall coordinates (u along the wall, y up). Ranges include the white frame.
local walls = {
	front = { windows = { { -1, 3, 3, 7 }, { 6, 10, 3, 7 } }, door = { -8, -5, 0, 5 } },
	back = { windows = { { -9, -5, 3, 7 }, { 4, 8, 3, 7 } } },
	left = { windows = { { -3, 1, 3, 7 } } },
	right = { windows = { { -3, 1, 3, 7 } } },
}

local function wallCell(side, u, y)
	local w = walls[side]
	for _, win in w.windows do
		if u >= win[1] and u <= win[2] and y >= win[3] and y <= win[4] then
			if u == win[1] or u == win[2] or y == win[3] or y == win[4] then
				return C.Frame, "solid"
			end
			return C.Glass, "glass"
		end
	end
	local d = w.door
	if d and u >= d[1] - 1 and u <= d[2] + 1 and y <= d[4] + 1 then
		if u == d[1] - 1 or u == d[2] + 1 or y == d[4] + 1 then
			return C.Frame, "solid"
		end
		if u == d[2] - 1 and y == 2 then
			return C.Knob, "metal"
		end
		return (u % 2 == 0) and C.DoorA or C.DoorB, "wood"
	end
	return C.Wall, "solid"
end

-- Walls
local X0, X1, Z0, Z1, H = Config.X0, Config.X1, Config.Z0, Config.Z1, Config.WALL_HEIGHT
for y = 0, H - 1 do
	for x = X0, X1 do
		for z = Z0, Z1 do
			if x == X0 or x == X1 or z == Z0 or z == Z1 then
				local side, u
				if z == Z1 then
					side, u = "front", x
				elseif z == Z0 then
					side, u = "back", x
				elseif x == X0 then
					side, u = "left", z
				else
					side, u = "right", z
				end
				local color, kind = wallCell(side, u, y)
				put(x, y, z, color, kind)
			end
		end
	end
end

-- Cream gable triangles under the roof at both ends
for k = 0, 8 do
	for z = Z0 + 1 + k, Z1 - 1 - k do
		put(X0, H + k, z, C.Wall)
		put(X1, H + k, z, C.Wall)
	end
end

-- Brick chimney on the back slope, with a dark cap
for y = H, 21 do
	local color = (y % 2 == 0) and C.BrickA or C.BrickB
	for x = 6, 7 do
		for z = -5, -4 do
			put(x, y, z, color)
		end
	end
end
for x = 5, 8 do
	for z = -6, -3 do
		if not (x >= 6 and x <= 7 and z >= -5 and z <= -4) then
			put(x, 22, z, C.Cap)
		end
	end
end

-- Stepped red roof: two rows per layer on each slope, 1 stud overhang all round
for k = 0, 9 do
	local color = (k % 2 == 0) and C.RoofA or C.RoofB
	local rows = { Z1 + 1 - k, Z1 - k, Z0 - 1 + k, Z0 + k }
	for _, z in rows do
		for x = X0 - 1, X1 + 1 do
			put(x, H + k, z, color)
		end
	end
end

---------------------------------------------------------------- build parts
local house = Instance.new("Folder")
house.Name = "House"

for _, key in order do
	local c = cells[key]
	local p = Instance.new("Part")
	p.Name = "Block"
	p.Anchored = true
	p.Size = Vector3.one
	p.CFrame = CFrame.new(c.x + 0.5, c.y + 0.5, c.z + 0.5)
	p.Color = c.color
	if c.kind == "glass" then
		p.Material = Enum.Material.Glass
		p.Transparency = 0.45
		p.TopSurface = Enum.SurfaceType.Smooth
		p.BottomSurface = Enum.SurfaceType.Smooth
	elseif c.kind == "wood" then
		p.Material = Enum.Material.Wood
		p.TopSurface = Enum.SurfaceType.Smooth
		p.BottomSurface = Enum.SurfaceType.Smooth
	elseif c.kind == "metal" then
		p.Material = Enum.Material.Metal
		p.Reflectance = 0.2
	else
		-- Plastic with studs on top and holes below: the LEGO look
		p.Material = Enum.Material.Plastic
		p.TopSurface = Enum.SurfaceType.Studs
		p.BottomSurface = Enum.SurfaceType.Inlet
	end
	p.Parent = house
end

-- Chimney smoke (not part of the house, it never breaks)
local smokeAnchor = Instance.new("Part")
smokeAnchor.Name = "ChimneySmoke"
smokeAnchor.Anchored = true
smokeAnchor.CanCollide = false
smokeAnchor.CanQuery = false
smokeAnchor.CanTouch = false
smokeAnchor.Transparency = 1
smokeAnchor.Size = Vector3.new(2, 0.5, 2)
smokeAnchor.CFrame = CFrame.new(7, 22.5, -4)
local smoke = Instance.new("ParticleEmitter")
smoke.Texture = "rbxasset://textures/particles/smoke_main.dds"
smoke.Color = ColorSequence.new(Color3.fromRGB(225, 225, 225), Color3.fromRGB(180, 180, 185))
smoke.Transparency = NumberSequence.new({
	NumberSequenceKeypoint.new(0, 0.6),
	NumberSequenceKeypoint.new(1, 1),
})
smoke.Size = NumberSequence.new({
	NumberSequenceKeypoint.new(0, 1.2),
	NumberSequenceKeypoint.new(1, 5),
})
smoke.Lifetime = NumberRange.new(3, 5)
smoke.Rate = 6
smoke.Speed = NumberRange.new(3, 5)
smoke.SpreadAngle = Vector2.new(12, 12)
smoke.Acceleration = Vector3.new(1.5, 0.5, 0)
smoke.RotSpeed = NumberRange.new(-30, 30)
smoke.Rotation = NumberRange.new(0, 360)
smoke.Parent = smokeAnchor
smokeAnchor.Parent = workspace

-- Warm light inside, so the windows glow a little
local lamp = Instance.new("Part")
lamp.Name = "HouseLamp"
lamp.Anchored = true
lamp.CanCollide = false
lamp.CanQuery = false
lamp.CanTouch = false
lamp.Transparency = 1
lamp.Size = Vector3.one
lamp.CFrame = CFrame.new(0, 8, 0)
local light = Instance.new("PointLight")
light.Color = Color3.fromRGB(255, 200, 140)
light.Brightness = 1.5
light.Range = 22
light.Shadows = true
light.Parent = lamp
lamp.Parent = workspace

house.Parent = workspace -- parent last: the breaker script waits for this folder
print(("[LegoHouse] built %d blocks"):format(#order))

---------------------------------------------------------------- spawn
-- Default CFrame looks toward -Z, which is straight at the front wall.
local spawn = Instance.new("SpawnLocation")
spawn.Name = "Spawn"
spawn.Anchored = true
spawn.Neutral = true
spawn.Duration = 0
spawn.Size = Vector3.new(6, 0.4, 6)
spawn.CFrame = CFrame.new(Config.SPAWN_POSITION)
spawn.Color = Color3.fromRGB(245, 245, 245)
spawn.Material = Enum.Material.SmoothPlastic
spawn.TopSurface = Enum.SurfaceType.Smooth
spawn.Parent = workspace

---------------------------------------------------------------- lighting effects
local atmosphere = Instance.new("Atmosphere")
atmosphere.Density = 0.28
atmosphere.Haze = 1.2
atmosphere.Color = Color3.fromRGB(235, 225, 210)
atmosphere.Decay = Color3.fromRGB(150, 160, 190)
atmosphere.Parent = Lighting

local cc = Instance.new("ColorCorrectionEffect")
cc.Saturation = 0.12
cc.Contrast = 0.05
cc.TintColor = Color3.fromRGB(255, 248, 238)
cc.Parent = Lighting

local bloom = Instance.new("BloomEffect")
bloom.Intensity = 0.4
bloom.Size = 20
bloom.Threshold = 1.6
bloom.Parent = Lighting
