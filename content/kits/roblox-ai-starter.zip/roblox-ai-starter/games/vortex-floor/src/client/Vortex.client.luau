-- Sinks the block floor into a spinning whirlpool funnel under every player; blocks spring back behind them.
-- LocalScript in StarterPlayerScripts; moves only blocks near players each frame with workspace:BulkMoveTo.

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")

local Config = require(ReplicatedStorage:WaitForChild("Shared"):WaitForChild("VortexConfig"))

local N = Config.GridSize
local S = Config.BlockSize
local HALF = N * S / 2
local BASE_Y = Config.FloorTop - S / 2

local R = Config.Radius
local DEPTH = Config.Depth
local RIPPLE_AMP = Config.RippleAmp
local RIPPLE_W = Config.RippleWidth
local SWIRL_AMP = Config.SwirlAmp
local SPIN = Config.SpinSpeed
local K = Config.Stiffness
local DAMP = Config.Damping

local REACH = R + RIPPLE_W * 2 -- funnel influence radius
local REACH2 = REACH * REACH
local BOX = math.ceil(REACH / S)

local sqrt, sin, exp, atan2, floor, abs, max, min, clamp =
	math.sqrt, math.sin, math.exp, math.atan2, math.floor, math.abs, math.max, math.min, math.clamp

---------------------------------------------------------------------------
-- Wait for the server-built floor
---------------------------------------------------------------------------
local floorFolder = workspace:WaitForChild("VortexFloor")
local expected = floorFolder:GetAttribute("BlockCount") or N * N
while #floorFolder:GetChildren() < expected do
	task.wait(0.1)
end

local COUNT = N * N
local parts: { BasePart } = table.create(COUNT)
local baseX = table.create(COUNT, 0)
local baseZ = table.create(COUNT, 0)
local parity = table.create(COUNT, 0)

for _, p in ipairs(floorFolder:GetChildren()) do
	if p:IsA("BasePart") then
		local i = clamp(floor((p.Position.X + HALF) / S), 0, N - 1)
		local j = clamp(floor((p.Position.Z + HALF) / S), 0, N - 1)
		local idx = i * N + j + 1
		parts[idx] = p
		baseX[idx] = -HALF + (i + 0.5) * S
		baseZ[idx] = -HALF + (j + 0.5) * S
		parity[idx] = (i + j) % 2
	end
end

---------------------------------------------------------------------------
-- Colour palette: -1 = deepest (dark), 0 = rest (blue), +1 = rim (light blue)
---------------------------------------------------------------------------
local LEVELS = 41
local MID = (LEVELS - 1) / 2
local palette = { [0] = table.create(LEVELS), [1] = table.create(LEVELS) }
for p = 0, 1 do
	local base = (p == 0) and Config.BaseColor or Config.AltColor
	for b = 0, LEVELS - 1 do
		local v = (b - MID) / MID
		local c
		if v < 0 then
			-- ease so blocks darken quickly as they start to sink
			c = base:Lerp(Config.DeepColor, 1 - (1 + v) ^ 1.6)
		else
			c = base:Lerp(Config.RimColor, v)
		end
		palette[p][b + 1] = c
	end
end
local REST_BUCKET = MID + 1

---------------------------------------------------------------------------
-- Per-block simulation state (flat arrays, no allocations per frame)
---------------------------------------------------------------------------
local offset = table.create(COUNT, 0) -- current height offset
local velocity = table.create(COUNT, 0)
local sentOffset = table.create(COUNT, 0) -- last offset written to the part
local bucket = table.create(COUNT, REST_BUCKET)
local target = table.create(COUNT, 0)
local glow = table.create(COUNT, 0)
local stamp = table.create(COUNT, 0) -- frame number when target was written

local active = {} -- list of block indices being simulated
local activePos = table.create(COUNT, 0) -- index in `active`, 0 = not active
local activeCount = 0

local moveParts = table.create(4096)
local moveCFrames = table.create(4096)

local frame = 0
local clock = 0

local function activate(idx)
	if activePos[idx] == 0 then
		activeCount += 1
		active[activeCount] = idx
		activePos[idx] = activeCount
	end
end

local function deactivate(slot)
	local idx = active[slot]
	local last = active[activeCount]
	active[slot] = last
	activePos[last] = slot
	active[activeCount] = nil
	activeCount -= 1
	activePos[idx] = 0
end

-- Writes this frame's funnel shape around one player into target/glow.
local function stampFunnel(cx: number, cz: number, phase: number)
	local ci = floor((cx + HALF) / S)
	local cj = floor((cz + HALF) / S)
	local i0, i1 = max(ci - BOX, 0), min(ci + BOX, N - 1)
	local j0, j1 = max(cj - BOX, 0), min(cj + BOX, N - 1)

	for i = i0, i1 do
		local rowBase = i * N + 1
		local dx = (-HALF + (i + 0.5) * S) - cx
		local dx2 = dx * dx
		for j = j0, j1 do
			local dz = (-HALF + (j + 0.5) * S) - cz
			local d2 = dx2 + dz * dz
			if d2 <= REACH2 then
				local idx = rowBase + j
				local r = sqrt(d2)
				local t = r / R
				local theta = atan2(dz, dx)

				-- smooth bowl, flat at the bottom and at the rim
				local h = 0
				local swirl = 0
				if t < 1 then
					local q = 1 - t * t
					h = -DEPTH * q * q
					-- three spiral arms turning inside the funnel
					swirl = SWIRL_AMP * sin(3 * theta + 0.55 * r - phase) * (t * (1 - t) * 4)
				end

				-- rippling, spinning band around the rim
				local rd = (r - R) / RIPPLE_W
				local rim = exp(-rd * rd)
				local ripple = RIPPLE_AMP * rim * sin(1.1 * r - phase * 1.7 + 3 * theta)

				local value = h + swirl + ripple
				local g = rim * (0.75 + 0.25 * sin(3 * theta - phase * 1.3))

				if stamp[idx] ~= frame then
					stamp[idx] = frame
					target[idx] = value
					glow[idx] = g
					activate(idx)
				else
					-- two funnels overlapping: keep the deeper one, the brighter rim
					if value < target[idx] then
						target[idx] = value
					end
					if g > glow[idx] then
						glow[idx] = g
					end
				end
			end
		end
	end
end

local function step(dt: number)
	dt = min(dt, 1 / 30)
	frame += 1
	clock += dt
	local phase = clock * SPIN

	for _, player in ipairs(Players:GetPlayers()) do
		local character = player.Character
		local root = character and character:FindFirstChild("HumanoidRootPart")
		if root then
			local pos = (root :: BasePart).Position
			if pos.Y > -30 and abs(pos.X) < HALF + REACH and abs(pos.Z) < HALF + REACH then
				stampFunnel(pos.X, pos.Z, phase)
			end
		end
	end

	local damping = exp(-DAMP * dt)
	local moveCount = 0
	local slot = 1
	while slot <= activeCount do
		local idx = active[slot]
		local tgt, g = 0, 0
		if stamp[idx] == frame then
			tgt = target[idx]
			g = glow[idx]
		end

		local off = offset[idx]
		local vel = (velocity[idx] + (tgt - off) * K * dt) * damping
		off += vel * dt

		local settled = tgt == 0 and abs(off) < 0.004 and abs(vel) < 0.03
		if settled then
			off = 0
			vel = 0
		end
		offset[idx] = off
		velocity[idx] = vel

		local part = parts[idx]
		if part then
			if abs(off - sentOffset[idx]) > 0.002 or (settled and sentOffset[idx] ~= 0) then
				sentOffset[idx] = off
				moveCount += 1
				moveParts[moveCount] = part
				moveCFrames[moveCount] = CFrame.new(baseX[idx], BASE_Y + off, baseZ[idx])
			end

			-- colour: darker with depth, light blue on the rim and on ripple crests
			local depthFrac = clamp(-off / DEPTH, 0, 1)
			local crest = max(off, 0) / RIPPLE_AMP
			local v = clamp(g * 0.85 + crest * 0.35 - depthFrac, -1, 1)
			local b = settled and REST_BUCKET or floor(v * MID + MID + 0.5) + 1
			if b ~= bucket[idx] then
				bucket[idx] = b
				part.Color = palette[parity[idx]][b]
			end
		end

		if settled then
			deactivate(slot) -- swapped-in block is processed at this same slot
		else
			slot += 1
		end
	end

	if moveCount > 0 then
		-- trim stale entries from a bigger previous frame
		for k = moveCount + 1, #moveParts do
			moveParts[k] = nil
			moveCFrames[k] = nil
		end
		workspace:BulkMoveTo(moveParts, moveCFrames, Enum.BulkMoveMode.FireCFrameChanged)
	end
end

-- PreSimulation: blocks move before physics, so the character stands on the funnel smoothly
RunService.PreSimulation:Connect(step)
